/// <reference types='Cypress'/>

const { should } = require("chai");

describe('Assignment', () => {
  beforeEach(() => {
    
    cy.visit('https://demo.guru99.com/insurance/v1/index.php')
  })
  it('Registration', () => {
   
    cy.register();
    cy.title().should('eq', 'https://demo.guru99.com/insurance/v1/index.php');
    
  })
  it('Loginfailure', () =>
  {
    cy.fixture('loginDetails.json').then((d) => {
      
      cy.login("mail@123.com","444");
      expect(response.statusCode).to.equal(200);
      
    })
  })

  it('SuccessLogin', () =>
  {
    cy.fixture('loginDetails.json').then((d) => {
      
      cy.login(d.email,d.password);
      expect(response.statusCode).to.equal(200);
      
    })
  })

  it('RequestQuotation', () =>
  {
    cy.fixture('loginDetails.json').then((d) => {
      
      cy.login(d.email,d.password);
      expect(response.statusCode).to.equal(200);
      
    })

    cy.get('#ui-id-2').click();
    cy.get('input[value="Save Quotation"]').click();
    cy.url().expect().to.equal('https://demo.guru99.com/insurance/v1/new_quotation.php');
      
    })

    it('RetriveQuotation', () =>
  {
    cy.fixture('loginDetails.json').then((d) => {
      
      cy.login(d.email,d.password);
      expect(response.statusCode).to.equal(200);
      var output = document.getElementsByTagName('b');
      
    })

    cy.get('#ui-id-3').click();
    cy.get('input[placeholder="identification number"]').type(output)
    cy.get('input[value="Retrieve"]').click();
    cy.url().expect().to.equal('https://demo.guru99.com/insurance/v1/retrieve_quotation.php');
      
    })

    it('Profile', () =>
    {
      cy.fixture('loginDetails.json').then((d) => {
        
        cy.login(d.email,d.password);
        expect(response.statusCode).to.equal(200);
        
        
      })
  
      cy.get('#ui-id-4').click();
      
        
      })

      it('EditProfile', () =>
      {
        cy.fixture('loginDetails.json').then((d) => {
          
          cy.login(d.email,d.password);
          expect(response.statusCode).to.equal(200);
          
          
        })
    
        cy.get('#ui-id-5').click();
        cy.get('input[value="Update User"]').click({ force: true });
        
          
        })

        it('Logout', () =>
      {
        cy.fixture('loginDetails.json').then((d) => {
          
          cy.login(d.email,d.password);
          expect(response.statusCode).to.equal(200);
          
          
        })
    
        cy.get('input[value="Log out"]').click();
        cy.title().should('eq', 'https://demo.guru99.com/insurance/v1/index.php');
        
        
          
        })

  })



