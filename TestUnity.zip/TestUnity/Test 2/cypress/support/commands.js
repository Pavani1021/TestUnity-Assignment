/// <reference types='Cypress'/>
const { minSatisfying } = require("cypress/vue2/dist/cypress-vue2.cjs");



     Cypress.Commands.add('register', () => { 
        cy.fixture('registerData.json', null).then((formDetails) => {
        cy.visit('https://demo.guru99.com/insurance/v1/index.php');
        cy.get('a[href="register.php"]').click();
        cy.get('inpu[id="temail"]').select(formDetails.title);
        cy.get('input[id="user_firstname"]').type(formDetails.firstName);
        cy.get('input[id="user_surname"]').type(formDetails.surName);
        cy.get('input[id="user_phone"]').type(formDetails.phone);
        cy.get('select[id = "user_dateofbirth_1i"]').select(formDetails.dateOfBirth.year);
        cy.get('select[id = "user_dateofbirth_2i"]').select(formDetails.dateOfBirth.month);
        cy.get('select[id = "user_dateofbirth_3i"]').select(formDetails.dateOfBirth.date);
        cy.get('select[id = "user_licenceperiod"]').select(formDetails.licencePeriod);
        cy.get('select[id = "user_occupation_id"]').select(formDetails.occupation);
        cy.get('input[id="user_address_attributes_street"]').type(formDetails.addressStreet);
        cy.get('input[id="user_address_attributes_city"]').type(formDetails.city);
        cy.get('input[id="user_address_attributes_county"]').type(formDetails.country);
        cy.get('input[id="user_address_attributes_postcode"]').type(formDetails.postCode);
        cy.get('input[id="user_user_detail_attributes_email"]').type(formDetails.email);
        cy.get('input[id="user_user_detail_attributes_password"]').type(formDetails.password);
        cy.get('input[id="user_user_detail_attributes_password_confirmation"]').type(formDetails.confirmPassword);
        cy.get('input[value="Create"]').click();
          })
    
        
        
         })
         Cypress.Commands.add('login', (e1,p1) => {
            cy.visit('https://demo.guru99.com/insurance/v1/index.php');
             cy.get('input[id="email"]').type(e1);
             cy.get('input[id="password"]').type(p1);
             cy.get('input[value="Log in"]').click();

        })
         
         